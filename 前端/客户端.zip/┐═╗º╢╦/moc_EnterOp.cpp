/****************************************************************************
** Meta object code from reading C++ file 'EnterOp.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Chat/opreate/EnterOp.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'EnterOp.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_EnterOp_t {
    QByteArrayData data[28];
    char stringdata0[304];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EnterOp_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EnterOp_t qt_meta_stringdata_EnterOp = {
    {
QT_MOC_LITERAL(0, 0, 7), // "EnterOp"
QT_MOC_LITERAL(1, 8, 9), // "isEntered"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 8), // "UserInfo"
QT_MOC_LITERAL(4, 28, 8), // "userInfo"
QT_MOC_LITERAL(5, 37, 9), // "noEntered"
QT_MOC_LITERAL(6, 47, 12), // "errorEntered"
QT_MOC_LITERAL(7, 60, 10), // "disConnect"
QT_MOC_LITERAL(8, 71, 8), // "isAddNew"
QT_MOC_LITERAL(9, 80, 4), // "User"
QT_MOC_LITERAL(10, 85, 4), // "user"
QT_MOC_LITERAL(11, 90, 9), // "nowAddNew"
QT_MOC_LITERAL(12, 100, 14), // "loginAndLogout"
QT_MOC_LITERAL(13, 115, 2), // "qq"
QT_MOC_LITERAL(14, 118, 6), // "status"
QT_MOC_LITERAL(15, 125, 13), // "messageSignal"
QT_MOC_LITERAL(16, 139, 7), // "Message"
QT_MOC_LITERAL(17, 147, 3), // "msg"
QT_MOC_LITERAL(18, 151, 14), // "outlineMessage"
QT_MOC_LITERAL(19, 166, 14), // "QList<Message>"
QT_MOC_LITERAL(20, 181, 12), // "dealFileSend"
QT_MOC_LITERAL(21, 194, 4), // "code"
QT_MOC_LITERAL(22, 199, 29), // "dealOutlineRequestFileReceive"
QT_MOC_LITERAL(23, 229, 15), // "QList<FileDate>"
QT_MOC_LITERAL(24, 245, 18), // "dealFileSendFailed"
QT_MOC_LITERAL(25, 264, 21), // "dealOnlineFileReceive"
QT_MOC_LITERAL(26, 286, 8), // "FileDate"
QT_MOC_LITERAL(27, 295, 8) // "fileData"

    },
    "EnterOp\0isEntered\0\0UserInfo\0userInfo\0"
    "noEntered\0errorEntered\0disConnect\0"
    "isAddNew\0User\0user\0nowAddNew\0"
    "loginAndLogout\0qq\0status\0messageSignal\0"
    "Message\0msg\0outlineMessage\0QList<Message>\0"
    "dealFileSend\0code\0dealOutlineRequestFileReceive\0"
    "QList<FileDate>\0dealFileSendFailed\0"
    "dealOnlineFileReceive\0FileDate\0fileData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EnterOp[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x06 /* Public */,
       5,    0,   82,    2, 0x06 /* Public */,
       6,    0,   83,    2, 0x06 /* Public */,
       7,    0,   84,    2, 0x06 /* Public */,
       8,    1,   85,    2, 0x06 /* Public */,
      11,    1,   88,    2, 0x06 /* Public */,
      12,    2,   91,    2, 0x06 /* Public */,
      15,    1,   96,    2, 0x06 /* Public */,
      18,    1,   99,    2, 0x06 /* Public */,
      20,    1,  102,    2, 0x06 /* Public */,
      22,    1,  105,    2, 0x06 /* Public */,
      24,    0,  108,    2, 0x06 /* Public */,
      25,    1,  109,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   13,   14,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, 0x80000000 | 19,    2,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, 0x80000000 | 23,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 26,   27,

       0        // eod
};

void EnterOp::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        EnterOp *_t = static_cast<EnterOp *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->isEntered((*reinterpret_cast< UserInfo(*)>(_a[1]))); break;
        case 1: _t->noEntered(); break;
        case 2: _t->errorEntered(); break;
        case 3: _t->disConnect(); break;
        case 4: _t->isAddNew((*reinterpret_cast< User(*)>(_a[1]))); break;
        case 5: _t->nowAddNew((*reinterpret_cast< User(*)>(_a[1]))); break;
        case 6: _t->loginAndLogout((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->messageSignal((*reinterpret_cast< Message(*)>(_a[1]))); break;
        case 8: _t->outlineMessage((*reinterpret_cast< QList<Message>(*)>(_a[1]))); break;
        case 9: _t->dealFileSend((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->dealOutlineRequestFileReceive((*reinterpret_cast< QList<FileDate>(*)>(_a[1]))); break;
        case 11: _t->dealFileSendFailed(); break;
        case 12: _t->dealOnlineFileReceive((*reinterpret_cast< FileDate(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (EnterOp::*)(UserInfo );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::isEntered)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::noEntered)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::errorEntered)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::disConnect)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(User );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::isAddNew)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(User );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::nowAddNew)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::loginAndLogout)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(Message );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::messageSignal)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(QList<Message> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::outlineMessage)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::dealFileSend)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(QList<FileDate> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::dealOutlineRequestFileReceive)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::dealFileSendFailed)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (EnterOp::*)(FileDate );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterOp::dealOnlineFileReceive)) {
                *result = 12;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject EnterOp::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_EnterOp.data,
    qt_meta_data_EnterOp,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *EnterOp::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EnterOp::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_EnterOp.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int EnterOp::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void EnterOp::isEntered(UserInfo _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void EnterOp::noEntered()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void EnterOp::errorEntered()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void EnterOp::disConnect()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void EnterOp::isAddNew(User _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void EnterOp::nowAddNew(User _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void EnterOp::loginAndLogout(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void EnterOp::messageSignal(Message _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void EnterOp::outlineMessage(QList<Message> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void EnterOp::dealFileSend(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void EnterOp::dealOutlineRequestFileReceive(QList<FileDate> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void EnterOp::dealFileSendFailed()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void EnterOp::dealOnlineFileReceive(FileDate _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
