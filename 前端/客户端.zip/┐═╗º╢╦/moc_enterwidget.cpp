/****************************************************************************
** Meta object code from reading C++ file 'enterwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Chat/enterwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'enterwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_EnterWidget_t {
    QByteArrayData data[32];
    char stringdata0[371];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EnterWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EnterWidget_t qt_meta_stringdata_EnterWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "EnterWidget"
QT_MOC_LITERAL(1, 12, 8), // "BackLand"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 11), // "EnterSignal"
QT_MOC_LITERAL(4, 34, 21), // "on_ButtonBack_clicked"
QT_MOC_LITERAL(5, 56, 21), // "on_ButtonLand_clicked"
QT_MOC_LITERAL(6, 78, 10), // "failedSlot"
QT_MOC_LITERAL(7, 89, 9), // "errorSlot"
QT_MOC_LITERAL(8, 99, 8), // "dealJson"
QT_MOC_LITERAL(9, 108, 8), // "UserInfo"
QT_MOC_LITERAL(10, 117, 8), // "userInfo"
QT_MOC_LITERAL(11, 126, 10), // "dealAddNew"
QT_MOC_LITERAL(12, 137, 4), // "User"
QT_MOC_LITERAL(13, 142, 4), // "user"
QT_MOC_LITERAL(14, 147, 8), // "loginOut"
QT_MOC_LITERAL(15, 156, 2), // "qq"
QT_MOC_LITERAL(16, 159, 6), // "status"
QT_MOC_LITERAL(17, 166, 11), // "dealMessage"
QT_MOC_LITERAL(18, 178, 7), // "Message"
QT_MOC_LITERAL(19, 186, 3), // "msg"
QT_MOC_LITERAL(20, 190, 18), // "dealOutlineMessage"
QT_MOC_LITERAL(21, 209, 14), // "QList<Message>"
QT_MOC_LITERAL(22, 224, 13), // "oulineMessage"
QT_MOC_LITERAL(23, 238, 10), // "dealNowAdd"
QT_MOC_LITERAL(24, 249, 12), // "dealFileSend"
QT_MOC_LITERAL(25, 262, 4), // "code"
QT_MOC_LITERAL(26, 267, 18), // "dealFileSendFailed"
QT_MOC_LITERAL(27, 286, 29), // "dealOutlineRequestFileReceive"
QT_MOC_LITERAL(28, 316, 15), // "QList<FileDate>"
QT_MOC_LITERAL(29, 332, 20), // "dealOnlieFileReceive"
QT_MOC_LITERAL(30, 353, 8), // "FileDate"
QT_MOC_LITERAL(31, 362, 8) // "fileData"

    },
    "EnterWidget\0BackLand\0\0EnterSignal\0"
    "on_ButtonBack_clicked\0on_ButtonLand_clicked\0"
    "failedSlot\0errorSlot\0dealJson\0UserInfo\0"
    "userInfo\0dealAddNew\0User\0user\0loginOut\0"
    "qq\0status\0dealMessage\0Message\0msg\0"
    "dealOutlineMessage\0QList<Message>\0"
    "oulineMessage\0dealNowAdd\0dealFileSend\0"
    "code\0dealFileSendFailed\0"
    "dealOutlineRequestFileReceive\0"
    "QList<FileDate>\0dealOnlieFileReceive\0"
    "FileDate\0fileData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EnterWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x06 /* Public */,
       3,    0,   95,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   96,    2, 0x08 /* Private */,
       5,    0,   97,    2, 0x08 /* Private */,
       6,    0,   98,    2, 0x08 /* Private */,
       7,    0,   99,    2, 0x08 /* Private */,
       8,    1,  100,    2, 0x08 /* Private */,
      11,    1,  103,    2, 0x08 /* Private */,
      14,    2,  106,    2, 0x08 /* Private */,
      17,    1,  111,    2, 0x08 /* Private */,
      20,    1,  114,    2, 0x08 /* Private */,
      23,    1,  117,    2, 0x08 /* Private */,
      24,    1,  120,    2, 0x08 /* Private */,
      26,    0,  123,    2, 0x08 /* Private */,
      27,    1,  124,    2, 0x08 /* Private */,
      29,    1,  127,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   15,   16,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,    2,
    QMetaType::Void, 0x80000000 | 30,   31,

       0        // eod
};

void EnterWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        EnterWidget *_t = static_cast<EnterWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->BackLand(); break;
        case 1: _t->EnterSignal(); break;
        case 2: _t->on_ButtonBack_clicked(); break;
        case 3: _t->on_ButtonLand_clicked(); break;
        case 4: _t->failedSlot(); break;
        case 5: _t->errorSlot(); break;
        case 6: _t->dealJson((*reinterpret_cast< UserInfo(*)>(_a[1]))); break;
        case 7: _t->dealAddNew((*reinterpret_cast< User(*)>(_a[1]))); break;
        case 8: _t->loginOut((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->dealMessage((*reinterpret_cast< Message(*)>(_a[1]))); break;
        case 10: _t->dealOutlineMessage((*reinterpret_cast< QList<Message>(*)>(_a[1]))); break;
        case 11: _t->dealNowAdd((*reinterpret_cast< User(*)>(_a[1]))); break;
        case 12: _t->dealFileSend((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->dealFileSendFailed(); break;
        case 14: _t->dealOutlineRequestFileReceive((*reinterpret_cast< QList<FileDate>(*)>(_a[1]))); break;
        case 15: _t->dealOnlieFileReceive((*reinterpret_cast< FileDate(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (EnterWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterWidget::BackLand)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (EnterWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&EnterWidget::EnterSignal)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject EnterWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_EnterWidget.data,
    qt_meta_data_EnterWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *EnterWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EnterWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_EnterWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int EnterWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void EnterWidget::BackLand()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void EnterWidget::EnterSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
