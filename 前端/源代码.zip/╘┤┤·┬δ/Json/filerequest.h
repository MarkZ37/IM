﻿#ifndef USERWITHMSG_H
#define USERWITHMSG_H

#include "Json/user.h"
#include "Json/message.h"

class filerequest
{
private:


};

#endif // #USERWITHMSG_H
